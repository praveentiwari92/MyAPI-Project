package com.AP;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TC_Pricing {
	

	WebDriver driver;
	@BeforeClass
	public void TestSetup() throws InterruptedException
	{
		
		
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.assignmentprime.com/pricing.php");
		 Thread.sleep(3000);
		 // Close Country Pop-up
		 driver.findElement(By.xpath("//i[@class='australia']")).click();
		 Thread.sleep(3000);
		 // close register pop-up
		 driver.findElement(By.xpath("//a[@class='close close_popup']")).click();
		 Thread.sleep(2000);
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,200)");
		 Thread.sleep(2000);
		 // Select Services
		 driver.findElement(By.id("ass_group_list")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//option[contains(text(),'Dissertation & PHD Thesis')]")).click();
		 Thread.sleep(2000);
		 // Select Subject
		 driver.findElement(By.id("assignment_subject")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//option[contains(text(),'Commerce')]")).click();
		 Thread.sleep(2000);
		 
		 // Select Pages
		 driver.findElement(By.id("pages_count_parent")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[@id='pages_count_parent']//option[3]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.className("price_text")).click();
		 
		 
}
	@Test
	public void Price()
	{
		driver.get("https://www.assignmentprime.com/order-now.php");
		System.out.println("Order Submited Successfully");
		driver.quit();
		
	
}
}
