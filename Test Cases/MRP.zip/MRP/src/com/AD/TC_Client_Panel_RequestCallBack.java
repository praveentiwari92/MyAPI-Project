	package com.AD;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TC_Client_Panel_RequestCallBack {
	
WebDriver driver;
	
	@BeforeClass
	public void TestSetup() throws InterruptedException
	{
		
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 
		 //Open URL
		 driver.get("https://www.assignmentdesk.co.uk");
		 Thread.sleep(2000);
		 
		 // Close country popup
		 driver.findElement(By.xpath("//a[contains(text(),'UK')]")).click();
		 Thread.sleep(5000);
		 
		 // Close seasonal offers popup
		 driver.findElement(By.xpath("//a[@class='close agree']")).click();
		 Thread.sleep(2000);
		 
		 //when i Click on login link it should be redirect on login page 
		 driver.findElement(By.xpath("//a[@class='login']")).click();
		 
		 // AND it should be display login form on page 
		 Thread.sleep(2000);
		 
		 // Parameter for login
		 driver.findElement(By.xpath("//input[@id='UserUsername']")).sendKeys("testcognus@gmail.com");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//input[@id='UserPassword']")).sendKeys("user123");
		 Thread.sleep(2000);
		 
		 // When i click on submit button it should be redirect on dashboard
		 driver.findElement(By.xpath("//button[@name='submit']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.className("contact-btn")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[@class='callback']")).click();
		 Thread.sleep(3000);
		 // Select Hours
		 driver.findElement(By.xpath("//*[@id=\"request_form\"]/ul/li[2]/div/select[1]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"request_form\"]/ul/li[2]/div/select[1]/option[5]")).click();
		 Thread.sleep(2000);
		 // Select Minute
		 driver.findElement(By.xpath("//*[@id=\"request_form\"]/ul/li[2]/div/select[2]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"request_form\"]/ul/li[2]/div/select[2]/option[3]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//textarea[@id='r_message']")).sendKeys("Tester");
		 Thread.sleep(2000);
		 String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
		 Thread.sleep(2000);
		 driver.findElement(By.id("rightside_captcha_code_side")).sendKeys(captchaVal);
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//button[contains(text(),'Submit Callback Request')]")).click();
	}
	
	@Test
	private void Request_Call_Back() {
		driver.get("https://www.assignmentdesk.co.uk/customer_panel/Customerorder/add");
		System.out.println("Test Run Successfully");
		driver.quit();

	}

}
