package com.IAH.au;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_Sample_Form {
WebDriver driver;
	
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
	
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.instantassignmenthelp.com.au/sample-on-accounting-theory-assignment");
		 Thread.sleep(10000);
		 driver.findElement(By.xpath("//*[@id=\"dialogs\"]/div/a")).click();
		 Thread.sleep(2000);
		 
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,3500)");
		 Thread.sleep(2000);
		 driver.findElement(By.className("download_btn")).click();
		 Thread.sleep(1000);			
		 
		 driver.findElement(By.id("email_download")).sendKeys("testcognus@gmail.com");
		 Thread.sleep(1000);
		 driver.findElement(By.id("phone_download")).sendKeys("1234567890");
		 Thread.sleep(1000);
		 String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
		 Thread.sleep(2000);
		 driver.findElement(By.id("captcha_download")).sendKeys(captchaVal);
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"sample_download\"]/ul/li[5]/button")).click();
		 
		 
		 
		 

}

	@Test
	public void Sample_Form()
	{
		
		driver.get("https://www.instantassignmenthelp.com.au/customer_panel/login");
		System.out.println("Test Run Successfully");
		driver.quit();
		
	}	
	}