package com.AP;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TC_Contact_us {
	
	WebDriver driver;
	@BeforeClass
	public void TestSetup() throws InterruptedException
	{
		
		
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.assignmentprime.com/contact-us.php");
		 Thread.sleep(3000);
		 // Close Country Pop-up
		 driver.findElement(By.xpath("//i[@class='australia']")).click();
		 Thread.sleep(3000);
		 // close register pop-up
		 driver.findElement(By.xpath("//a[@class='close close_popup']")).click();
		 Thread.sleep(2000);
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,200)");
		 Thread.sleep(2000);
		 // Fill Form Details 
		 driver.findElement(By.xpath("//input[@id='rightside_full_name_side']")).sendKeys("Tester");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//input[@id='rightside_email_side']")).sendKeys("Testcognus@gmail.com");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//input[@id='rightside_phones_side']")).sendKeys("1234567890");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//textarea[@id='rightside_message_side']")).sendKeys("tester");
		 Thread.sleep(2000);
		 String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
		 Thread.sleep(2000);
		 driver.findElement(By.id("rightside_captcha_code_side")).sendKeys(captchaVal);
		 Thread.sleep(2000);
 
		 }
	
	@Test
	public void Contact_Us()
	{
		driver.get("https://www.assignmentprime.com/thanksenquiry.php");
		System.out.println("Form Submited Successfully");
		driver.quit();
	
}
	
	 
}
