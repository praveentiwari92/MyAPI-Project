package com.IAH.au;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_Register {
	
WebDriver driver;
	
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
	
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.instantassignmenthelp.com.au/signup.php");
		 Thread.sleep(2000);
		 driver.findElement(By.id("signup_name")).sendKeys("tester");
		 Thread.sleep(2000);
		 driver.findElement(By.id("signup_email")).sendKeys("testerr139@gmail.com");
		 Thread.sleep(2000);
		 driver.findElement(By.id("signup_phone")).sendKeys("1234567890");
		 Thread.sleep(2000);
		 String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
		 Thread.sleep(2000);
		 driver.findElement(By.id("captcha_code")).sendKeys(captchaVal);
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"reg_form\"]/button")).click();
 
		 
	}
	
	@Test
	public void Register()
	{
		
		driver.get("https://www.instantassignmenthelp.com.au/customer_panel/dashboard");
		System.out.println("Test Run Successfully");
		driver.quit();
		
	}
	
	
	

}
