package com.AP;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TC_Answer_Form {
	WebDriver driver;
	@BeforeClass
	public void TestSetup() throws InterruptedException
	{
		
		
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.assignmentprime.com/answers/accounting/management-accounting");
		 Thread.sleep(3000);
		 // Close Country Pop-up
		 driver.findElement(By.xpath("//i[@class='australia']")).click();
		 Thread.sleep(3000);
		 // close register pop-up
		 driver.findElement(By.xpath("//a[@class='close close_popup']")).click();
		 Thread.sleep(2000);
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,500)");
		 Thread.sleep(2000);
		 // Click on download full answer button
		 driver.findElement(By.xpath("//button[@class='download-btn cboxElement']")).click();
		 Thread.sleep(2000);
		 
		 driver.findElement(By.xpath("//input[@id='email_download']")).sendKeys("testcognus@gmail.com");
		 Thread.sleep(2000);
		 
		 driver.findElement(By.xpath("//input[@id='phone_download']")).sendKeys("1234567890");
		 Thread.sleep(2000);
		 
		 String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
		 Thread.sleep(2000);
		 driver.findElement(By.id("captcha_download")).sendKeys(captchaVal);
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//button[@class='submit_btn']")).click();
		 
		 
	}
	@Test
	public void Contact_Us()
	{
		driver.get("https://www.assignmentprime.com/customer_panel/");
		System.out.println("Answer Form Submited Successfully");
		driver.quit();
		
	
}

}
