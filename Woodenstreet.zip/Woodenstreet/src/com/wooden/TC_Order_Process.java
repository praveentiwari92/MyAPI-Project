package com.wooden;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;

public class TC_Order_Process {
	
	WebDriver driver;
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
		
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		/* driver.get("https://www.woodenstreet.com/");
	 Thread.sleep(10000);
		 driver.navigate().refresh();
		 
		 driver.findElement(By.xpath("/html/body/header/nav/ul/li[3]/a")).click();
		 Thread.sleep(500);
		 driver.findElement(By.xpath("/html/body/header/nav/ul/li[3]/ul/li/article[1]/a[3]")).click();
		 Thread.sleep(1000);
		 driver.findElement(By.xpath("//*[@id=\"article_9996\"]/a/figure/img")).click();
		 Thread.sleep(1500);*/
		 
		 	driver.get("https://www.woodenstreet.com/walken-bed-with-storage-walnut-finish");
			Thread.sleep(300);	 
  				
  		
		 	WebElement h1 = driver.findElement(By.tagName("h1"));
			System.out.println(h1.getText());
			Thread.sleep(1000);
			driver.findElement(By.id("pin")).sendKeys("313001");
		 	Thread.sleep(1000);
		 	driver.findElement(By.xpath("//*[@id=\"main_product_details\"]/div/div[2]/div[4]/input[2]")).click();
		 	Thread.sleep(1000);
		 	String myText = driver.findElement(By.xpath("//*[@id=\"msg\"]")).getText();
	        System.out.println("Success " + myText);
	        Thread.sleep(300);
	        driver.findElement(By.xpath("//*[@id=\"button-cart\"]")).click();
	        Thread.sleep(1000);
	        driver.navigate().to("https://www.woodenstreet.com/cart");
	        Thread.sleep(1000);
	        driver.findElement(By.xpath("/html/body/div[1]/div[2]/div[3]/a")).click();
	        Thread.sleep(1000);
	        driver.navigate().to("https://www.woodenstreet.com/guest");
	        Thread.sleep(1000);
	        driver.findElement(By.id("email")).sendKeys("tester@gmail.com");
	        Thread.sleep(1000);
	        driver.findElement(By.id("postcode")).sendKeys("313001");
	        Thread.sleep(1000);
	        driver.findElement(By.id("address_1")).sendKeys("123");
	        Thread.sleep(1000);
	        driver.findElement(By.id("address_2")).sendKeys("123123 udr");
	        Thread.sleep(1000);
	        driver.findElement(By.id("address_3")).sendKeys("123123 udr");
	        Thread.sleep(1000);
	        driver.findElement(By.id("telephone")).sendKeys("1234567890");
	        Thread.sleep(1000);
	        driver.findElement(By.id("firstname")).sendKeys("tester");
	        Thread.sleep(1000);
	        driver.findElement(By.id("lastname")).sendKeys("WS");
	        Thread.sleep(1000);
	        driver.findElement(By.id("button-guest")).click();
	        Thread.sleep(1000);
	        driver.navigate().to("https://www.woodenstreet.com/payment");
	        Thread.sleep(1000);
	        driver.findElement(By.xpath("//*[@id=\"button-confirm\"]")).click();
	        
}



@Test
public void TestRun()
{
	driver.get("");
	
}
}