package com.IAH.au;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_Write_Review {

	 WebDriver driver;

		@BeforeTest
		public void TestSetup() throws InterruptedException
		{
		
			System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
			 driver = new ChromeDriver();
			 driver.manage().window().maximize();
			 //Open URL
			 driver.get("https://www.instantassignmenthelp.com.au/reviews.php");
			 Thread.sleep(5000);
			 driver.findElement(By.xpath("//*[@id=\"dialogs\"]/div/a")).click();
			 Thread.sleep(5000);
			 
			 driver.findElement(By.id("review-btn")).click();
			 Thread.sleep(2000);
			 
			 
			 
			 driver.findElement(By.xpath("//*[@id=\"review_form\"]/div[2]/input")).sendKeys("Tester");
			 Thread.sleep(1000);
			 driver.findElement(By.xpath("//*[@id=\"review_form\"]/div[1]/input")).sendKeys("Tester");
			 Thread.sleep(1000);
			 driver.findElement(By.xpath("//*[@id=\"review_form\"]/div[3]/input")).sendKeys("Testcognus@gmail.com");
			 Thread.sleep(1000);
			 driver.findElement(By.xpath("//*[@id=\"review_form\"]/div[4]/input")).sendKeys("testy");
			 Thread.sleep(1000);
			 driver.findElement(By.xpath("//*[@id=\"review_form\"]/div[6]/textarea")).sendKeys("Test");
			 Thread.sleep(1000);
			 
			 String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
			 Thread.sleep(2000);
			 driver.findElement(By.xpath("//*[@id=\"review_form\"]/div[8]/input")).sendKeys(captchaVal);
			 Thread.sleep(2000);
			 driver.findElement(By.xpath("//*[@id=\"review_form\"]/button")).click(); 
		
			
			 
			 
			 
			 
}
		@Test
		public void Write_Review()
		{
			
			driver.get("https://www.instantassignmenthelp.com.au/reviews.php");
			System.out.println("Test Run Successfully");
			driver.quit();
			
			
		}
		
}