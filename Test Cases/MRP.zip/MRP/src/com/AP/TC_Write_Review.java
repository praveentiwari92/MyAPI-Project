package com.AP;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TC_Write_Review {
	
	WebDriver driver;
	@BeforeClass
	public void TestSetup() throws InterruptedException
	{
		
		
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.assignmentprime.com/reviews.php");
		 Thread.sleep(3000);
		 // Close Country Pop-up
		 driver.findElement(By.xpath("//i[@class='australia']")).click();
		 Thread.sleep(3000);
		 // close register pop-up
		 driver.findElement(By.xpath("//a[@class='close close_popup']")).click();
		 Thread.sleep(2000);
		driver.findElement(By.className("review-btn")).click();
		Thread.sleep(2000);
		
		driver.findElement(By.id("title_r")).sendKeys("Tester");
		Thread.sleep(2000);
		
		driver.findElement(By.id("name_r")).sendKeys("Tester");
		Thread.sleep(2000);
		
		driver.findElement(By.id("contain_r")).sendKeys("Tester");
		Thread.sleep(2000);
		
		String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
		Thread.sleep(2000);
		driver.findElement(By.id("captcha_code_review")).sendKeys(captchaVal);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@name='reviews_submit']")).click();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		
		
		
	
}
	
	@Test
	public void Review()
	{
		driver.get("https://www.assignmentprime.com/reviews.php");
		System.out.println("Review Submited Successfully");
		driver.close();
	}

}
