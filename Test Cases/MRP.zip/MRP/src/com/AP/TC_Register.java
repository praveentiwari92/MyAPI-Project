package com.AP;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TC_Register {
	WebDriver driver;
	@BeforeClass
	public void TestSetup() throws InterruptedException
	{
		
		
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.assignmentprime.com/");
		 Thread.sleep(3000);
		 // Close Country Pop-up
		 driver.findElement(By.xpath("//i[@class='australia']")).click();
		 Thread.sleep(3000);
		 // close register pop-up
		 driver.findElement(By.xpath("//a[@class='close close_popup']")).click();
		 Thread.sleep(2000);
		// Click on login
				 driver.findElement(By.className("login")).click();
				 Thread.sleep(2000);
		// Click on Signup Link
		 driver.findElement(By.xpath("//a[contains(text(),'Sign Up')]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.id("signup_name")).sendKeys("Tester");
		 Thread.sleep(2000);
		 driver.findElement(By.id("signup_email")).sendKeys("Testcognus212@gmail.com");
		 Thread.sleep(2000);
		 driver.findElement(By.id("footer_country")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//option[contains(text(),'Algeria')]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.id("signup_phone")).sendKeys("456792255");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[7]//input[1]")).click();
		 
				 
				 
	}
	
@Test
public void Register()
{
	driver.get("https://www.assignmentprime.com/customer_panel/dashboard");
	System.out.println("Register Successfully");
	driver.quit();

}
}
