package com.AP;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Tc_Price_Calculator_On_Service_Page {
	
	WebDriver driver;
	double d =59.25;
	@BeforeClass
	public void TestSetup() throws InterruptedException
	{
		
		
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.assignmentprime.com/accounting-assignment-help");
		 Thread.sleep(3000);
		 // Close Country Pop-up
		 driver.findElement(By.xpath("//i[@class='australia']")).click();
		 Thread.sleep(3000);
		 // close register pop-up
		 driver.findElement(By.xpath("//a[@class='close close_popup']")).click();
		 Thread.sleep(2000);
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,200)");
		 Thread.sleep(2000);
		 		// Select Services
		 		 driver.findElement(By.id("ass_group_list")).click();
		 		 Thread.sleep(2000);
		 		 driver.findElement(By.xpath("//option[contains(text(),'Online Exam | Question based test Papers')]")).click();
		 		 Thread.sleep(2000);
		 		 
		 		 // Select Subject
				 driver.findElement(By.id("assignment_subject")).click();
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//option[contains(text(),'Accounts')]")).click();
				 Thread.sleep(2000);
				 
				 // Select Question
				 driver.findElement(By.id("no_of_q")).click();
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//select[@id='no_of_q']//option[3]")).click();
				 Thread.sleep(2000);
				 
				 // Select Words
				 driver.findElement(By.id("no_of_w")).click();
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//*[@id=\"no_of_w\"]/option[4]")).click();
				 Thread.sleep(2000);
				 
				 // Select urgency
				 driver.findElement(By.id("urgency")).click();
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//option[contains(text(),'3 Days')]")).click();
				 if(d==59.25)
				 {
					 System.out.println("Calculated Amount Is :"+d);
				 }
				 else
				 {
					 System.out.println("Amount not matched");
				 }
				 Thread.sleep(2000);	
				 // click on Order Now Button
				 driver.findElement(By.xpath("//section[@class='outer content clearfix']//input[4]")).click();
				 
				 
}
	
	@Test
	public void Service_Page()
	{
		
		driver.get("https://www.assignmentprime.com/order-now.php");
		System.out.println("Calculator Is Working Properly");
		driver.close();
	}
}
