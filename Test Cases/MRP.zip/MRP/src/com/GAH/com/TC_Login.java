package com.GAH.com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_Login {
	WebDriver driver; 
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
	
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.globalassignmenthelp.com/customer_panel");
		 Thread.sleep(1000);
		 driver.findElement(By.id("UserUsername")).sendKeys("testcognus@gmail.com");
		 Thread.sleep(1000);
		 driver.findElement(By.id("UserPassword")).sendKeys("user123");
		 Thread.sleep(1000);
		 driver.findElement(By.xpath("//*[@id=\"form-submit\"]/div[1]/section/button")).click();
}

	@Test
	public void Login() {
	
		driver.get("https://www.globalassignmenthelp.com/customer_panel/dashboard");
		System.out.println("Test Run Successfully");
		driver.quit();
	}	
	
}