package com.AD;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Tc_OrderWithLogin {
	
WebDriver driver;
	
	@BeforeClass
	public void TestSetup() throws InterruptedException
	{
		
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 
		 //Open URL
		 driver.get("https://www.assignmentdesk.co.uk/samples");
		 Thread.sleep(2000);
		 
		 // Close country popup
		 driver.findElement(By.xpath("//a[contains(text(),'UK')]")).click();
		 Thread.sleep(5000);
		 
		 // Close seasonal offers popup
		 driver.findElement(By.xpath("//a[@class='close agree']")).click();
		 Thread.sleep(2000);
		 
		 //when i Click on login link it should be redirect on login page 
		 driver.findElement(By.xpath("//a[@class='login']")).click();
		 
		 // AND it should be display login form on page 
		 Thread.sleep(2000);
		 
		 // Parameter for login
		 driver.findElement(By.xpath("//input[@id='UserUsername']")).sendKeys("testcognus@gmail.com");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//input[@id='UserPassword']")).sendKeys("user123");
		 Thread.sleep(2000);
		 
		 // When i click on submit button it should be redirect on dashboard
		 driver.findElement(By.xpath("//button[@name='submit']")).click();
		 
		 Thread.sleep(2000);
		 // Click on Add New order Button and Add order form must be display
		 driver.findElement(By.xpath("//a[contains(@class,'hglt_btn')]")).click();
		 Thread.sleep(2000);
		 // Topic
		 driver.findElement(By.xpath("//input[@id='topic']")).sendKeys("MBA");
		 Thread.sleep(2000);
		 
		 // Select type of Services
		 driver.findElement(By.xpath("//select[@id='assignment_group_sle']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//option[contains(text(),'Assignment | Coursework | Term Paper')]")).click();
		 Thread.sleep(2000);
		 
		 // Select subject
		 driver.findElement(By.xpath("//select[@id='assignment_subject']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//option[contains(text(),'Travel & Tourism')]")).click();
		 Thread.sleep(2000);
		 
		// Select Pages
				 driver.findElement(By.xpath("//select[@id='pages_count']")).click();
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//article[@id='pages_count_parent']//option[3]")).click();
				 Thread.sleep(2000);
		 
				// Select urgency
				 driver.findElement(By.xpath("//select[@id='urgency']")).click();
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//option[contains(text(),'3 Days')]")).click();
				 Thread.sleep(2000);
				 // Enter Message box value
				 driver.findElement(By.xpath("//textarea[@id='message']")).sendKeys("Tester");
				 Thread.sleep(2000);
				 JavascriptExecutor js = (JavascriptExecutor) driver;
				 js.executeScript("window.scrollBy(0,200)");
				 Thread.sleep(2000);
				 
				 // Uplaod file
				 WebElement uploadElement = driver.findElement(By.id("file1"));
				 Thread.sleep(2000);
				 uploadElement.sendKeys("C:\\Users\\user\\Pictures\\bill.png");
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//button[@id='submitcheckorder']")).click();
				 
				 driver.navigate().refresh();
				
		 
		}
	@Test
	private void OrderWithLogin() {
		driver.get("https://www.assignmentdesk.co.uk/customer_panel/Customerorder/add");
		System.out.println("Test Run Successfully");
		driver.quit();

	}

}
