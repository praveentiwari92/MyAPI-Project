package com.wooden;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class BaseTest {
	
	static ExtentTest test;

	static ExtentReports report;
	
	
	@BeforeSuite
	public void setup()
	{
		report = new ExtentReports(System.getProperty("user.dir")+"\\ExtentReportResults.html");
		test = report.startTest("test");		
	}
	
	@AfterMethod
	public void getResult(ITestResult result)
	{
		if (result.getStatus()==ITestResult.FAILURE)
		{
			
			 test.log(LogStatus.FAIL, "Test Case Failed");
		}
		
		else if(result.getStatus()==ITestResult.SUCCESS)
		{
			 test.log(LogStatus.PASS, "Test Case Passed");
		}
		
		else
		{
			 test.log(LogStatus.SKIP, "Test Case Skipped");
			
			
		}
		
	}
	
	@AfterSuite
	public void tearDown()
	{
		report.flush();
	}
}
