package com.wooden;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;

public class TC_Custom {
	WebDriver driver;
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
		
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.woodenstreet.com/custom-furniture");
		 Thread.sleep(10000);
		 driver.navigate().refresh();
		 //driver.findElement(By.className("close")).click();
		 Thread.sleep(800);
		 driver.findElement(By.className("heading-bold")).click();
		 Thread.sleep(800);
		 driver.findElement(By.xpath("//*[@id=\"myFormCustom2\"]/div[1]/input")).sendKeys("Tester");
		 Thread.sleep(800);
		 driver.findElement(By.xpath("//*[@id=\"myFormCustom2\"]/div[2]/input")).sendKeys("testcognus@gmail.com");
		 Thread.sleep(800);
		 driver.findElement(By.xpath("//*[@id=\"myFormCustom2\"]/div[3]/input")).sendKeys("9116009505");
		 Thread.sleep(800);
		 driver.findElement(By.xpath("//*[@id=\"myFormCustom2\"]/div[4]/input")).sendKeys("313001");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"myFormCustom2\"]/div[5]/textarea")).sendKeys("Tester");
		 Thread.sleep(1500);
		 driver.findElement(By.xpath("//*[@id=\"myFormCustom2\"]/div[6]/input")).click();
		  	
	}
	
	
	@Test
	public void TestRun()
	{
		driver.get("https://www.woodenstreet.com/custom-furniture");
		
	}
	
}
