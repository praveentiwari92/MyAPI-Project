package com.wooden;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;

public class TC_Ask_Question extends BaseTest {
	
	
	
	WebDriver driver;
/*	static ExtentTest test;

	static ExtentReports report;

	@BeforeClass

	public static void startTest()

	{
		
	report = new ExtentReports(System.getProperty("user.dir")+"\\ExtentReportResults.html");

	test = report.startTest("ExtentDemo");
	

	}*/
	
	@Test
	public void TestRun()throws InterruptedException
	{
		
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 test.log(LogStatus.INFO, "URL Opening");
		 //Open URL
		 driver.get("http://testing.woodenstreet.com/laptop-tables?type=header_menu");
		 Thread.sleep(8000);
		 driver.navigate().refresh();
		 //driver.findElement(By.className("close")).click();
		 Thread.sleep(2000);
		 test.log(LogStatus.INFO, "Click on Ask Question Button");
		 WebElement element = driver.findElement(By.xpath("//*[@id=\"questions\"]/a"));
		 Actions actions = new Actions(driver);
		 actions.moveToElement(element);
		 actions.perform();
		 Thread.sleep(1000);
		 driver.findElement(By.xpath("//a[@class='btn btn-warning']")).click();
		 Thread.sleep(2000);
		 
		 test.log(LogStatus.INFO, "Enter Question");
		 driver.findElement(By.xpath("//textarea[@id='question']")).sendKeys("tester");
		 Thread.sleep(800);
		 
		 test.log(LogStatus.INFO, "Enter Name");
		 driver.findElement(By.xpath("//*[@id=\"faqform_submit\"]/div[2]/input")).sendKeys("tester");
		 Thread.sleep(800);
		 
		 test.log(LogStatus.INFO, "Enter Email");
		 driver.findElement(By.xpath("//*[@id=\"faqform_submit\"]/div[3]/input")).sendKeys("Testognus@gmail.com");
		 Thread.sleep(800);
		 
		 test.log(LogStatus.INFO, "Enter Mobile No.");
		 driver.findElement(By.xpath("//*[@id=\"faqform_submit\"]/div[4]/input")).sendKeys("1234567890");
		 Thread.sleep(800);
		 
		 test.log(LogStatus.INFO, "Enter Address.");
		 driver.findElement(By.xpath("//*[@id=\"faqform_submit\"]/div[5]/input")).sendKeys("udaipur");
		 Thread.sleep(800);
		 
		 test.log(LogStatus.INFO, "Click on Submit Button.");
		 driver.findElement(By.id("product_faq_submit")).click();
		 Thread.sleep(1000);
		 
		/* if(driver.findElement(By.xpath("//*[@id=\"review-popup\"]/div/div/div/span")).isDisplayed())
				 {
			 
			 test.log(LogStatus.PASS, "Question Posted Successfully");
				 }else{
					 test.log(LogStatus.FAIL, "Test Failed");
				 }
		 */
	
				 }
	
	@AfterClass
	public static void endTest()

	{

	report.endTest(test);

	report.flush();
	

	}
		 
		 
		
	}
	


