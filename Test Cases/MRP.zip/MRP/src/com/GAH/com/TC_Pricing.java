package com.GAH.com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_Pricing {
	
WebDriver driver; 
	
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
	
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.globalassignmenthelp.com/pricing.php");
		 Thread.sleep(5000);
		 driver.findElement(By.xpath("//*[@id=\"dialogs\"]/div/a")).click();
		 Thread.sleep(11000);
		
		
		 // Select Service
		 driver.findElement(By.id("ass_group_list")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"ass_group_list\"]/option[2]")).click();
		 Thread.sleep(2000);
		 // Select Subject
		 driver.findElement(By.id("assignment_subject")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"assignment_subject\"]/optgroup[1]/option[1]")).click();
		 Thread.sleep(2000);
		// Select Pages
		 driver.findElement(By.id("pages_count")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"pages_count\"]/option[3]")).click();
		 Thread.sleep(2000);
		 		// Select Service
				 driver.findElement(By.id("ass_group_list")).click();
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//*[@id=\"ass_group_list\"]/option[6]")).click();
				 Thread.sleep(2000);
					
				 // Select Subject				
				 driver.findElement(By.xpath("//*[@id=\"assignment_subject\"]")).click();
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//*[@id=\"assignment_subject\"]/optgroup[1]/option[2]")).click();	 
			
				 // Select Question
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//*[@id=\"no_of_q\"]")).click();
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//*[@id=\"no_of_q\"]/option[4]")).click();
				 // Select Words
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//*[@id=\"no_of_w\"]")).click();
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//*[@id=\"no_of_w\"]/option[4]")).click();
				 Thread.sleep(2000);
		 
		 /*Actions actions = new Actions(driver);
		 WebElement menuOption = driver.findElement(By.className("price_text")).click();
		 actions.moveToElement(menuOption).perform();
		 System.out.println("Done Mouse hover on 'Order now");
		*/
		 driver.findElement(By.className("price_text")).click();

}
	@Test
	public void Pricing() {
	
		driver.get("https://www.globalassignmenthelp.com/order-now.php");
		System.out.println("Test Run Successfully");
		driver.quit();
	}
}