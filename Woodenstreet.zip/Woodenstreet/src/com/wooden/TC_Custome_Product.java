package com.wooden;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;

public class TC_Custome_Product {
	WebDriver driver;
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
		
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.woodenstreet.com/zadran-study-table-honey-finish");
		 Thread.sleep(10000);
		 driver.navigate().refresh();
		 //driver.findElement(By.className("close")).click();
		 Thread.sleep(800);
 
		 driver.findElement(By.className("desktop_customize_it")).click();
		 Thread.sleep(800);
		 driver.findElement(By.xpath("//*[@id=\"popup_form\"]/div[1]/input")).sendKeys("Tester");
		 Thread.sleep(800);
		 driver.findElement(By.xpath("//*[@id=\"popup_form\"]/div[2]/input")).sendKeys("Tester@gmail.com");
		 Thread.sleep(800);
		 driver.findElement(By.xpath("//*[@id=\"popup_form\"]/div[3]/input")).sendKeys("1234567890");
		 Thread.sleep(800);
		 driver.findElement(By.id("custom_pincode")).sendKeys("313001");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"popup_form\"]/div[5]/textarea")).sendKeys("Tester");
		 Thread.sleep(1500);
		 driver.findElement(By.id("formSubmitCustom")).click();
		  	
	}
	
	
	@Test
	public void TestRun()
	{
		driver.get("https://www.woodenstreet.com/zadran-study-table-honey-finish");
		
	}

}
