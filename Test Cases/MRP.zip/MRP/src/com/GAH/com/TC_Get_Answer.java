package com.GAH.com;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_Get_Answer {
	
WebDriver driver; 
	
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
	
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.globalassignmenthelp.com/answers/accounting/integration-of-managerial-accounting");
		 Thread.sleep(10000);
		 driver.findElement(By.xpath("//*[@id=\"dialogs\"]/div/a")).click();
		 Thread.sleep(2000);
		 
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,150)");

		 Thread.sleep(2000);
		 driver.findElement(By.className("download_btn")).click();
		 
		 Thread.sleep(2000);
		 driver.findElement(By.id("email_download")).sendKeys("Tester@gmail.com");
		 Thread.sleep(2000);
		 driver.findElement(By.id("phone_download")).sendKeys("1234567890");
		 Thread.sleep(2000);
		 
		 String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
		 Thread.sleep(2000);
		 driver.findElement(By.id("captcha_download")).sendKeys(captchaVal);
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("/html/body/div[3]/section[3]/div[2]/article[1]/div[2]/form/ul/li[5]/button")).click();
		 
	 
	}
	
	@Test
	public void Get_Answer()
	{
		driver.get("https://www.globalassignmenthelp.com/customer_panel/");
		System.out.println("Test Run Successfully");
		driver.quit();
		
		
		
	}

}
