package com.wooden;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;


public class TC_Franchies extends BaseTest {

	WebDriver driver;
	
	
	@Test
	public void TestRun()throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		
		 //Open URL
		 driver.get("http://testing.woodenstreet.com//furniture-franchise");
		 Thread.sleep(1000);
		 driver.findElement(By.id("export-name")).sendKeys("Tester");
		 Thread.sleep(1000);
		 driver.findElement(By.id("export-email")).sendKeys("Tester@gmail.com");
		 Thread.sleep(1000);
		 driver.findElement(By.id("export-phone")).sendKeys("1234567890");
		 Thread.sleep(1000);
		 driver.findElement(By.id("export-postcode")).sendKeys("313001");
		
		 Thread.sleep(2000);
		 driver.findElement(By.id("btn-submit")).click();
		 Thread.sleep(2000);
	/*	 if( driver.findElement(By.xpath("//div[@class='heading']")).isDisplayed())
		 {
			 test.log(LogStatus.PASS, "Test Run Successfully");
			 }else{
				 test.log(LogStatus.FAIL, "Test Failed");
			 }
	 		*/
	
	}
		@AfterClass
	
	public static void endTest()

	{

	report.endTest(test);

	report.flush();

	}
	
}
