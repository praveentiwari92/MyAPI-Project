package com.GAH.com;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_Contact_Us {

WebDriver driver; 
	
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
	
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.globalassignmenthelp.com/contact-us.php");
		 Thread.sleep(10000);
		 driver.findElement(By.xpath("//*[@id=\"dialogs\"]/div/a")).click();
		 Thread.sleep(2000);
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,200)");
		 Thread.sleep(2000);
		 // Name
		 driver.findElement(By.id("footer_fname")).sendKeys("tester");
		 Thread.sleep(2000);
		 // Email
		 driver.findElement(By.id("footer_email")).sendKeys("testcognus@gmail.com");
		 Thread.sleep(2000);
		 // Mobile No
		 driver.findElement(By.id("footer_phone")).sendKeys("1234657890");
		 Thread.sleep(2000);
		 // Message
		 driver.findElement(By.id("footer_message")).sendKeys("Tester");
		 Thread.sleep(2000);
		 String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
		 Thread.sleep(2000);
		 driver.findElement(By.id("footer_capcode")).sendKeys(captchaVal);
		 Thread.sleep(2000);
		 driver.findElement(By.id("contactsubmit")).click();
		 
		 
}

	@Test
	public void Contact() {
	
		driver.get("https://www.globalassignmenthelp.com/contact-us.php");
		System.out.println("Test Run Successfully");
		driver.quit();
	}
}