package com.GAH.au;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_ReqCallBack_From_Dashboard {
WebDriver driver; 
	
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
	
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.globalassignmenthelp.com.au");
		 Thread.sleep(5000);
		 // Close Register Popup
		 driver.findElement(By.xpath("//a[@class='close close_popup']")).click();
		 Thread.sleep(2000);
		 // click on Login
		 driver.findElement(By.xpath("//a[@class='user-icon']")).click();
		 Thread.sleep(2000);
		 // Fill Login form
		 driver.findElement(By.id("UserUsername")).sendKeys("testcognus@gmail.com");
		 Thread.sleep(2000);
		 driver.findElement(By.id("UserPassword")).sendKeys("user123");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//button[@name='submit']")).click();
		 Thread.sleep(2000);
		 if( driver.findElement(By.xpath("//a[contains(@class,'hglt_btn')]")).isDisplayed()){
			 System.out.println("Add New Order Is Available");
			 }else{
			 System.out.println("Add New Order Is Not Available and Test Case Failed");
			 }
		 
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//span[@class='contact-btn']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[@class='callback']")).click();
		 Thread.sleep(2000);
		 // Select Hours
		 driver.findElement(By.xpath("//*[@id=\"request_form\"]/ul/li[2]/div/select[1]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"request_form\"]/ul/li[2]/div/select[1]/option[4]")).click();
		 Thread.sleep(2000);
		 // Select minute
		 driver.findElement(By.xpath("//*[@id=\"request_form\"]/ul/li[2]/div/select[2]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"request_form\"]/ul/li[2]/div/select[2]/option[5]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//textarea[@id='r_message']")).sendKeys("Tester Req");
		 Thread.sleep(2000);
		 String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
		 Thread.sleep(2000);
		 driver.findElement(By.id("rightside_captcha_code_side")).sendKeys(captchaVal);
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//button[contains(text(),'Submit Callback Request')]")).click();
		 
		 
		 
		 
	}
	
	@Test
	public void ReqCallBack_Dashboard()
	{
		
		driver.get("https://www.globalassignmenthelp.com.au/customer_panel/Users");
		System.out.println("Query Submitted Successfully");
		driver.quit();
		
	}
	
}
