package com.wooden;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;

public class TC_Interior_Design {
	
	WebDriver driver;
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
		
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.woodenstreet.com/interior-designs");
		 Thread.sleep(10000);
		 driver.navigate().refresh();
		 
		 Thread.sleep(1000);
		 driver.findElement(By.id("interior_request_name1")).sendKeys("tester");
		 
		 Thread.sleep(1000);
		 driver.findElement(By.id("interior_request_email1")).sendKeys("testcognus@gmail.com");
		 
		 Thread.sleep(1000);
		 driver.findElement(By.id("interior_request_phone1")).sendKeys("1234567890");
		 
		 Thread.sleep(1000);
		 driver.findElement(By.id("interior_request_pincode1")).sendKeys("313001");
		 
		 Thread.sleep(1500);
		 driver.findElement(By.id("interior_request_comment1")).sendKeys("tester");
		 
		 Thread.sleep(1000);
		 driver.findElement(By.id("book_consultantion_btn")).click();
		 
		 
		 
		 
}
	
	@Test
	public void TestRun()
	{
		driver.get("");
		
	}

}
