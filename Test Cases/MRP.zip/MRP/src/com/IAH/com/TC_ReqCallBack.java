package com.IAH.com;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_ReqCallBack {
	
WebDriver driver;
	
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
	
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.instantassignmenthelp.com/");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"dialog\"]/div/ul/li[1]/a")).click();
		 Thread.sleep(15000);
		// driver.findElement(By.id("popupfoot")).click();
		// Thread.sleep(2000);
		 driver.findElement(By.className("js-open-modal")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.id("full_name_side")).sendKeys("Tester");
		 Thread.sleep(1000);
		 driver.findElement(By.id("footer_email_side")).sendKeys("Testcognus@gmail.com");
		 Thread.sleep(2000);
		 driver.findElement(By.id("time")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"time\"]/option[3]")).click();
		 Thread.sleep(1000);
		 driver.findElement(By.id("phones_side")).sendKeys("1234567890");
		 Thread.sleep(1000);
		 driver.findElement(By.id("message_side")).sendKeys("Tester");
		 Thread.sleep(2000);
		 String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
	 
		 driver.findElement(By.id("captcha_code_side")).sendKeys(captchaVal);
		 Thread.sleep(2000);
		 driver.findElement(By.id("btn_sidebar")).click();
	
	}
	
	@Test
	public void Call_Back() {
		
		driver.get("https://www.instantassignmenthelp.com/thanks.php");
		System.out.println("Test Run Successfully");
		driver.quit();
		
	}

}
