package com.AD;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;



public class TC_Inquiry {
WebDriver driver;
	
	
	
	
	@BeforeClass
	public void TestSetup() 
	{
		
		
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		
		 
}

	@Test
	public void Inquiry()throws InterruptedException
	{
		
		 //Open URL
		 driver.get("https://www.assignmentdesk.co.uk/");
		
		 Thread.sleep(2000);
		 // Close country popup
		 driver.findElement(By.xpath("//a[contains(text(),'UK')]")).click();
		 Thread.sleep(5000);
		 // Close seasonal offers popup
		 driver.findElement(By.xpath("//a[@class='close agree']")).click();
		 Thread.sleep(2000);
		 // Open inquiry form
		
		 driver.findElement(By.xpath("//button[@class='md-trigger inquiry-now']")).click();
		 Thread.sleep(2000);
		 // Name
		 driver.findElement(By.xpath("//input[@id='full_name_side']")).sendKeys("Tester");
		 Thread.sleep(2000);
		 // Mail
		 driver.findElement(By.xpath("//input[@id='email_side']")).sendKeys("Testcognus@gmail.com");
		 Thread.sleep(2000);
		 // Mobile No
		 driver.findElement(By.xpath("//input[@id='phones_side']")).sendKeys("1234567890");
		 Thread.sleep(2000);
		 // Message
		 driver.findElement(By.xpath("//textarea[@id='message_side']")).sendKeys("Tester");
		 Thread.sleep(2000);
		 // Captcha Code
		 String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//input[@id='captcha_code_side']")).sendKeys(captchaVal);
		 Thread.sleep(2000);
		 // Submit
		 driver.findElement(By.xpath("//button[@id='btn_sidebar']")).sendKeys("Tester");
		 Thread.sleep(2000);
		System.out.println("Test Run Successfully");
		 Thread.sleep(2000);
		 driver.quit();
	}
	
	
}
