package com.GAH.au;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_Register {
WebDriver driver;

@BeforeTest
public void Register() throws InterruptedException {
	
	System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe");	
	driver=new ChromeDriver();
	driver.manage().window().maximize();
	// Open URL
	driver.get("https://www.globalassignmenthelp.com.au/signup.php");
	Thread.sleep(2000);
	// Enter Require Details for Register
	driver.findElement(By.xpath("//input[@placeholder='Name']")).sendKeys("Tester");
	Thread.sleep(2000);
	driver.findElement(By.xpath("//input[@placeholder='Email']")).sendKeys("testcognus119@gmail.com");
	Thread.sleep(2000);
	driver.findElement(By.id("rightside_country")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("//option[contains(text(),'Australia')]")).click();
	Thread.sleep(2000);
	driver.findElement(By.xpath("//input[@placeholder='Enter phone no.']")).sendKeys("1234567980");
	Thread.sleep(2000);
	driver.findElement(By.xpath("//button[@class='margn']")).click();
	
	if( driver.findElement(By.xpath("//a[@class='odr-btn']")).isDisplayed()){
		 System.out.println("User Regsitered Successfully");
		 }else{
		 System.out.println("Registration Failed");
		 }
	
}
	
@Test
public void Register_Test()
{
	driver.get("https://www.globalassignmenthelp.com/customer_panel/dashboard");
	
	

}
	

}
