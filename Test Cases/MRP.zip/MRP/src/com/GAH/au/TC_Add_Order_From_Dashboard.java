package com.GAH.au;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_Add_Order_From_Dashboard {
WebDriver driver; 
	
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
	
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.globalassignmenthelp.com.au");
		 Thread.sleep(5000);
		 // Close Register Popup
		 driver.findElement(By.xpath("//a[@class='close close_popup']")).click();
		 Thread.sleep(2000);
		 // click on Login
		 driver.findElement(By.xpath("//a[@class='user-icon']")).click();
		 Thread.sleep(2000);
		 // Fill Login form
		 driver.findElement(By.id("UserUsername")).sendKeys("testcognus@gmail.com");
		 Thread.sleep(2000);
		 driver.findElement(By.id("UserPassword")).sendKeys("user123");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//button[@name='submit']")).click();
		 Thread.sleep(2000);
		 if( driver.findElement(By.xpath("//a[contains(@class,'hglt_btn')]")).isDisplayed()){
			 System.out.println("Add New Order Is Available");
			 }else{
			 System.out.println("Add New Order Is Not Available and Test Case Failed");
			 }
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//a[contains(@class,'hglt_btn')]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.id("topic")).sendKeys("MBA");
		 Thread.sleep(2000);
		 driver.findElement(By.id("assignment_group_sle")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//option[contains(text(),'Assignment | Coursework | Term Paper')]")).click();
		 Thread.sleep(4000);
		 driver.findElement(By.id("assignment_subject")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//option[contains(text(),'SPSS')]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.id("message")).sendKeys("Tester");
		 Thread.sleep(2000);
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,-2000)");
		 Thread.sleep(2000);
		 WebElement uploadElement = driver.findElement(By.id("file1"));
		 Thread.sleep(1000);
		 uploadElement.sendKeys("C:\\Users\\user\\Pictures\\bill.png"); 
		 Thread.sleep(2000);
		 driver.findElement(By.id("submitcheckorder")).click();
		 
		
		
		
		 
		 
	}
	
	
	
	@Test
	public void Login()
	{
		
		driver.get("https://www.globalassignmenthelp.com.au/customer_panel/Users");
		System.out.println("Order Added Succesfully");
		driver.quit();
		
	}
	

	

}
