package com.wooden;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;

public class TC_Contact_Us {
	WebDriver driver;
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
		
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.woodenstreet.com/support-form");
		// Thread.sleep(10000);
		// driver.navigate().refresh();
		 //driver.findElement(By.className("close")).click();
		 Thread.sleep(800);
		 driver.findElement(By.xpath("/html/body/div[3]/div/ul/li[2]/a")).click();
		 Thread.sleep(800);
		 driver.findElement(By.id("name")).sendKeys("tester");
		 Thread.sleep(800);
		 driver.findElement(By.id("email")).sendKeys("tester@gmail.com");
		 Thread.sleep(800);
		 driver.findElement(By.id("phone")).sendKeys("1234567890");
		 Thread.sleep(800);
		 driver.findElement(By.id("product_name")).sendKeys("1234567890");
		 Thread.sleep(800);
		 driver.findElement(By.id("product_name")).sendKeys("L shap Sofa");
		 Thread.sleep(800);
		 driver.findElement(By.xpath("//*[@id=\"complaintForm\"]/div[5]/div")).click();
		 Thread.sleep(800);
		 driver.findElement(By.xpath("//*[@id=\"reason\"]/option[2]")).click();
		 Thread.sleep(800);
		 WebElement uploadElement = driver.findElement(By.id("my_file"));
		 Thread.sleep(800);
		 uploadElement.sendKeys("C:\\Users\\user\\Pictures\\bill.png"); 
		 Thread.sleep(1000);
		 driver.findElement(By.id("comments")).sendKeys("testing");
		 Thread.sleep(1000);
		 driver.findElement(By.id("submit_new_complaint")).click();
		 Thread.sleep(1000);
	 		String myText = driver.findElement(By.className("message1")).getText();
	        System.out.println("Success:" + myText);
		 
		
	
	}
	
	
		 @Test
			public void TestRun()
			{
				driver.get("https://www.woodenstreet.com/support-form");
				
			}
	

}
