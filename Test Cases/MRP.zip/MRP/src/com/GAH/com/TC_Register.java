package com.GAH.com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_Register {
	
	WebDriver driver; 
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
	
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.globalassignmenthelp.com/signup.php");
		 Thread.sleep(2000);
		 
		 driver.findElement(By.xpath("//*[@id=\"reg_form\"]/div[1]/div[1]/input")).sendKeys("Tester");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"reg_form\"]/div[1]/div[2]/input")).sendKeys("Tester115@gmail.com");
		 Thread.sleep(2000);
		 driver.findElement(By.id("rightside_country")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"rightside_country\"]/option[2]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"reg_form\"]/div[1]/div[4]/input[2]")).sendKeys("1456755555");
		 Thread.sleep(2000);
		 driver.findElement(By.className("margn")).click();
		
		 
	}
	
	@Test
	public void Register() {
	
		driver.get("https://www.globalassignmenthelp.com/customer_panel/dashboard");
		System.out.println("Test Run Successfully");
		driver.quit();
		
	}	
	

}
