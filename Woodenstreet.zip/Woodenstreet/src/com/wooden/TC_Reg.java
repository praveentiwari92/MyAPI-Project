package com.wooden;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;

public class TC_Reg {
	
WebDriver driver;
	
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
		

		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.woodenstreet.com");
		 Thread.sleep(11000);
		 driver.navigate().refresh();
		 Thread.sleep(1000);
		 driver.findElement(By.id("sign_up_popup_btn")).click();
		 
	
		 Thread.sleep(500);
		 driver.findElement(By.id("register_firstname")).sendKeys("tester");
		 Thread.sleep(500);
		 driver.findElement(By.id("register_email")).sendKeys("testcognusss102@gmail.com");
		 Thread.sleep(500);
		 driver.findElement(By.id("register_telephone")).sendKeys("1234567890");
		 Thread.sleep(500);
		 driver.findElement(By.id("register_pincode")).sendKeys("313001");
		 Thread.sleep(500);		 
		 driver.findElement(By.id("register_password")).sendKeys("123456");
		 Thread.sleep(500);
		 driver.findElement(By.xpath("//*[@id=\"signup_btn\"]")).click();
	
		 
	}
	
	@Test
	public void TestRun()
	{
		driver.get("https://www.woodenstreet.com");
	}

}
