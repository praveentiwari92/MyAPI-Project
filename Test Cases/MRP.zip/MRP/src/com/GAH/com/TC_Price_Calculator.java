package com.GAH.com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_Price_Calculator {
	
	WebDriver driver; 
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
	
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.globalassignmenthelp.com/");
		 Thread.sleep(5000);
		 driver.findElement(By.xpath("//*[@id=\"dialogs\"]/div/a")).click();
		 Thread.sleep(11000);
		 
		 driver.findElement(By.id("ass_group_list")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"ass_group_list\"]/option[3]")).click();
		 
		 Thread.sleep(4000);
		 driver.findElement(By.id("assignment_subject")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"assignment_subject\"]/optgroup[1]/option[1]")).click();
		 
		 Thread.sleep(2000);
		 driver.findElement(By.id("pages_count")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"pages_count\"]/option[3]")).click();
		 
		 
		 Thread.sleep(2000);
		 driver.findElement(By.id("urgency")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"urgency\"]/option[14]")).click();
		 Thread.sleep(2000);
		 
		 
		 
		 if(driver.getPageSource().contains("� 17.48"))
		 {
		 System.out.println("Text is Present");
		 }
		 else
		 {
		 System.out.println("Text is not Present");
		 }
	
		 
	     Thread.sleep(2000);
	     driver.findElement(By.xpath("/html/body/section[1]/div/div[2]/div[4]/div[2]/input")).click();
		 
		 
		 
		 
		 
	}
	@Test
	public void Price_Calcultr() {
	
		driver.get("https://www.globalassignmenthelp.com/order-now.php");
		System.out.println("Test Run Successfully");
		driver.quit();
		
	}	

}
