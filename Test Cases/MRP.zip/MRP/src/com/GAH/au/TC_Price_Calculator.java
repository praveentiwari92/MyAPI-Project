package com.GAH.au;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_Price_Calculator {
	WebDriver driver;
	
	
	String d = "AU$ 105.19";
	@BeforeTest
	public void Price_Calculator() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		// Open URL
		driver.get("https://www.globalassignmenthelp.com.au/");
		Thread.sleep(6000);
		// Close popup
		driver.findElement(By.xpath("//a[@class='close close_popup']")).click();
		
		 Thread.sleep(2000);
		 // Select Services
		 driver.findElement(By.id("ass_group_list")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//option[contains(text(),'Case Study | Report Writing')]")).click();
		 Thread.sleep(2000);
		// Select Subject
		 driver.findElement(By.id("assignment_subject")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//option[contains(text(),'Estate Management')]")).click();
		 Thread.sleep(2000);
		// Select Pages
				 driver.findElement(By.id("pages_count")).click();
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//div[@id='pages_count_parent']//option[5]")).click();
				 Thread.sleep(2000);
				// Select Urgency
				 driver.findElement(By.id("urgency")).click();
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//option[contains(text(),'1 Day')]")).click();
				 Thread.sleep(2000);
				 // Close cookies popup
				 driver.findElement(By.className("policy_cookie")).click();
				 Thread.sleep(2000);
				 // Submit Button
				 driver.findElement(By.xpath("//input[@class='green-btn calcuator_button1']")).click();
		 
		if(d=="AU$ 105.19")
		{
			System.out.println("Calculated Values is :"+d);
			
		}
		else 
		{
			System.out.println("Calculated Values is not match");
		}
		
}
@Test
public void Price_Calcy()
{
	driver.get("https://www.globalassignmenthelp.com.au/order-now.php");
	driver.quit();
	
}
}
