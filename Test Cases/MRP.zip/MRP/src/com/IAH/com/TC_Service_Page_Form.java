package com.IAH.com;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_Service_Page_Form {
	
WebDriver driver;
	
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
	
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.instantassignmenthelp.com/cheap-assignment-help");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"dialog\"]/div/ul/li[1]/a")).click();
		 Thread.sleep(15000);
		// driver.findElement(By.id("popupfoot")).click();
		// Thread.sleep(2000);
		 driver.findElement(By.id("full_name")).sendKeys("Tester");
		 Thread.sleep(2000);
		 driver.findElement(By.id("footer_email")).sendKeys("Testcognus@gmail.com");
		 Thread.sleep(2000);
		 driver.findElement(By.id("phones")).sendKeys("1234567890");
		 Thread.sleep(2000);
		 driver.findElement(By.id("message")).sendKeys("Testing");
		 Thread.sleep(2000);
		 String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
		 driver.findElement(By.id("captcha_code")).sendKeys(captchaVal);
	     Thread.sleep(2000);
	 	 driver.findElement(By.id("btn_submit1")).click();
	 

}
	
	@Test
	public void Service_Page() {
		
		driver.get("https://www.instantassignmenthelp.com/order-now.php");
		System.out.println("Test Run Successfully");
		driver.quit();
	}

}