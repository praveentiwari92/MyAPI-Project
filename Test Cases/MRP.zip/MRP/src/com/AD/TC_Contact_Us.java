package com.AD;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TC_Contact_Us {

WebDriver driver;
	
	@BeforeClass
	public void TestSetup() throws InterruptedException
	{
		
		
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.assignmentdesk.co.uk/contact-us.php");
		 Thread.sleep(2000);
		 // Close country popup
		 driver.findElement(By.xpath("//a[contains(text(),'UK')]")).click();
		 Thread.sleep(5000);
		 // Close seasonal offers popup
		 driver.findElement(By.xpath("//a[@class='close agree']")).click();
		 Thread.sleep(2000);
		 
		 driver.findElement(By.xpath("//input[@id='full_name']")).sendKeys("Tester");
		 Thread.sleep(2000);
		 
		 driver.findElement(By.xpath("//input[@id='footer_email']")).sendKeys("Testcognus@gmail.com");
		 Thread.sleep(2000);
		 
		 driver.findElement(By.id("phones")).sendKeys("123456456");
		 Thread.sleep(2000);

		 driver.findElement(By.id("message")).sendKeys("tester");
		 String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
		 Thread.sleep(2000);
		 driver.findElement(By.id("captcha_code")).sendKeys(captchaVal);
		 Thread.sleep(2000);
		 driver.findElement(By.id("btn_submit")).click();
		 
	}

	@Test
	public void Contact_us()
	{
		
		driver.get("https://www.assignmentdesk.co.uk/thanksenquiry.php");
		System.out.println("Test Run Successfully");
		 driver.quit();
	}
	
}
