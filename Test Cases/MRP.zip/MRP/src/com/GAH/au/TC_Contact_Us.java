package com.GAH.au;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_Contact_Us {
	
	WebDriver driver;
	@BeforeTest
	public void Contact_us() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe");	
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		// Open URL
		driver.get("https://www.globalassignmenthelp.com.au/contact-us.php");
		Thread.sleep(5000);
		 // Close Register Popup
		 driver.findElement(By.xpath("//a[@class='close close_popup']")).click();
		 Thread.sleep(2000);
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,200)");
		 Thread.sleep(2000);
		 driver.findElement(By.id("footer_fname")).sendKeys("Tester");
		 Thread.sleep(2000);
		 driver.findElement(By.id("footer_email")).sendKeys("Testcognus@gmail.com");
		 Thread.sleep(2000);
		 driver.findElement(By.id("footer_phone")).sendKeys("1234567890");
		 Thread.sleep(2000);
		 driver.findElement(By.id("footer_message")).sendKeys("Tester message");
		 Thread.sleep(2000);
		 String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
		 Thread.sleep(2000);
		 driver.findElement(By.id("footer_capcode")).sendKeys(captchaVal);
		 Thread.sleep(2000);
		 driver.findElement(By.id("footersubmitcheck")).click();
			
		 
		
	}
	
	@Test
	public void Contact()
	{
		driver.get("https://www.globalassignmenthelp.com.au/thanksenquiry.php");
		if(driver.findElement(By.className("heading")).isDisplayed())
				{
			System.out.println("Thank You");
			
				}
		else {
			
			System.out.println("404 Page");
		}
		
		driver.quit();
		
	}

}
