package com.IAH.com;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_GetFullaAnswerForm {
	
	
WebDriver driver;
	
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
	
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.instantassignmenthelp.com/answers/finance/financial-planning");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"dialog\"]/div/ul/li[1]/a")).click();
		 Thread.sleep(15000);
		 // driver.findElement(By.id("popupfoot")).click();
		 // Thread.sleep(2000);
		 driver.findElement(By.className("download_btn")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.id("email_download")).sendKeys("Testcognus@gmail.com");
		 Thread.sleep(2000);
		 driver.findElement(By.id("phone_download")).sendKeys("1234567890");

		 Thread.sleep(2000);
		 String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:"); 
		 Thread.sleep(2000);
		 driver.findElement(By.id("captcha_download")).sendKeys(captchaVal);
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"load_sample\"]/ul/li[5]/button")).click();
	
		 
		 
	}
	@Test
	public void Get_Answer()
	{
		
		driver.get("https://www.instantassignmenthelp.com/customer_panel/");
		System.out.println("Test Run Succesfully");
		driver.quit();
	}

}
