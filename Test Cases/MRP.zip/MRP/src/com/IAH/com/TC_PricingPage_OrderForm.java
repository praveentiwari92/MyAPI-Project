package com.IAH.com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_PricingPage_OrderForm {

WebDriver driver;
	
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
	
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.instantassignmenthelp.com/price.php");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"dialog\"]/div/ul/li[1]/a")).click();
		 Thread.sleep(15000);
		// driver.findElement(By.id("popupfoot")).click();
		// Thread.sleep(2000);
		 
		 driver.findElement(By.id("ass_group_list")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"ass_group_list\"]/option[3]")).click();
		 Thread.sleep(2000);
		 
		 driver.findElement(By.id("assignment_subject")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"assignment_subject\"]/optgroup[1]/option[1]")).click();
		 Thread.sleep(2000);
		 
		 driver.findElement(By.id("pages_count")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"pages_count\"]/option[2]")).click();
		 Thread.sleep(2000);
		 
		 driver.findElement(By.id("urgency")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"urgency\"]/option[2]")).click();
		 Thread.sleep(2000);
		 
		 driver.findElement(By.className("btn")).click();
		 Thread.sleep(1000);
	     driver.navigate().to("https://www.instantassignmenthelp.com/order-now.php");
	     
	     System.out.println("Order Form Working Properly on Pricing Page");
		 
	}
	
	@Test
	public void Pricing() {
		
		driver.get("https://www.instantassignmenthelp.com/order-now.php");
		System.out.println("Order Form Working Properly on Pricing Page");
		driver.quit();
	}
	
}
