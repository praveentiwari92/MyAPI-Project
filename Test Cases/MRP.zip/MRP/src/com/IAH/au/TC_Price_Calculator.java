package com.IAH.au;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_Price_Calculator {
	
	 WebDriver driver;

		@BeforeTest
		public void TestSetup() throws InterruptedException
		{
		
			System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
			 driver = new ChromeDriver();
			 driver.manage().window().maximize();
			 //Open URL
			 driver.get("https://www.instantassignmenthelp.com.au/algebra-assignment-help");
			 Thread.sleep(5000);
			 driver.findElement(By.xpath("//*[@id=\"dialogs\"]/div/a")).click();
			 Thread.sleep(5000);
			 
			 JavascriptExecutor js = (JavascriptExecutor) driver;
			 js.executeScript("window.scrollBy(0,50)");
			 // select Services
			 driver.findElement(By.id("ass_group_list")).click();
			 Thread.sleep(2000);
			 driver.findElement(By.xpath("//*[@id=\"ass_group_list\"]/option[2]")).click();
			 Thread.sleep(2000);
			 // Select subject
			 driver.findElement(By.id("assignment_subject")).click();
			 Thread.sleep(2000);
			 driver.findElement(By.xpath("//*[@id=\"assignment_subject\"]/optgroup[1]/option[1]")).click();
			 Thread.sleep(2000);
			 // Select Page count
			 driver.findElement(By.xpath("//select[@id='pages_count']")).click();
			 Thread.sleep(2000);
			 driver.findElement(By.xpath("//*[@id=\"pages_count\"]/option[3]")).click();
			 Thread.sleep(2000);
			 // Select Urgency 
			 driver.findElement(By.xpath("//select[@id='urgency']")).click();
			 Thread.sleep(3000);
			 driver.findElement(By.xpath("//*[@id=\"urgency\"]/option[3]")).click();
			 Thread.sleep(2000);
			 driver.findElement(By.className("policy_cookie")).click();
			 Thread.sleep(2000);
			 // Select Currency Type
			 driver.findElement(By.id("currencies")).click();
			 Thread.sleep(2000);
			 driver.findElement(By.xpath("//*[@id=\"currencies\"]/option[2]")).click();
			 Thread.sleep(2000);
			 // Submit Form
			 driver.findElement(By.xpath("//*[@id=\"calcu_order_sidebar\"]/input[3]")).click();
			 
		 
			 
		}
		
		@Test
		public void Price_Calculator()
		{
			
			driver.get("https://www.instantassignmenthelp.com.au/order-now.php");
			System.out.println("Price Calculator working Properly");
			driver.quit();
			
			
		}
		
}
