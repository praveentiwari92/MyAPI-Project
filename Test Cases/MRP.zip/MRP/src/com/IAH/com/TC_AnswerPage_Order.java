package com.IAH.com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_AnswerPage_Order {
	
WebDriver driver;
	
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
	
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.instantassignmenthelp.com/answers");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"dialog\"]/div/ul/li[1]/a")).click();
		 Thread.sleep(10000);
		// driver.findElement(By.id("popupfoot")).click();
		// Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"sample_side_calculator\"]/ul/li[1]/input")).sendKeys("testcognus@gmail.com");
		 Thread.sleep(2000);
		 driver.findElement(By.id("ass_group_list")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"ass_group_list\"]/option[5]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.id("assignment_subject")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"assignment_subject\"]/optgroup[1]/option[3]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.id("pages_count")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"pages_count\"]/option[2]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.id("urgency")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"urgency\"]/option[2]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"sample_side_calculator\"]/ul/li[7]/input")).click();
		 
		 Thread.sleep(1000);
	     driver.navigate().to("https://www.instantassignmenthelp.com/order-now.php");
	     
	     
		 
		 
	
	}
	
	

	@Test
	public void TestRun()
	{
		
		driver.get("https://www.instantassignmenthelp.com/order-now.php");
		System.out.println("Order Form Working Properly on Answer Page");
		driver.quit();	
	}
	
	
}