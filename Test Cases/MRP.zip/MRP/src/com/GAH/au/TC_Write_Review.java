package com.GAH.au;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_Write_Review {
	
	WebDriver driver;
	@BeforeTest
	public void Review() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		// Open URL
		driver.get("https://www.globalassignmenthelp.com.au/reviews.php");
		
		Thread.sleep(5000);
		 // Close Register Popup
		 driver.findElement(By.xpath("//a[@class='close close_popup']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//a[@id='open_28271249']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//input[@id='title_r']")).sendKeys("Tester");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//input[@id='name_r']")).sendKeys("Tester");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//textarea[@id='contain_r']")).sendKeys("Tester");
		 Thread.sleep(2000);
		 String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
		 Thread.sleep(2000);
		 driver.findElement(By.id("captcha_code_review")).sendKeys(captchaVal);
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//button[@name='reviews_submit']")).click();
		
		
	}
	@Test
	public void Write_Review()
	{
		driver.get("https://www.globalassignmenthelp.com.au/reviews.php");
		System.out.println("---------Review Posted Successfully-----------");
		driver.quit();
		
	}

}
