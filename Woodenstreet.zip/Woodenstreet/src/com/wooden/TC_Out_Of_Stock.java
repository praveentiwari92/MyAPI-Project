package com.wooden;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_Out_Of_Stock {
	
	WebDriver driver;
	static int Count = 0;

	
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
	
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.woodenstreet.com/out-of-stock?type=product_breadcrumbs");
		 Thread.sleep(10000);
		 driver.findElement(By.id("loginclose")).click();
		// Page Scroll 
		 JavascriptExecutor jse = (JavascriptExecutor)driver;
		 for (int second = 0;; second++) {
	         if(second >=20){
	             break;
	         }
	             jse.executeScript("window.scrollBy(0,600)", ""); //y value �800� can be altered
	             Thread.sleep(1000);
	         } 
		 // Find Text by class
		 for (WebElement outofstock: driver.findElements(By.className("sold-send")))
			 
		 {
			 System.out.println(outofstock.getText());
			   Count++;
		 }
		 
		 System.out.println("Total Out of Stock Products on Page : " + Count);
		 
		// Find Text by class	 
		 for (WebElement productName: driver.findElements(By.className("sold-send")))
			 
		 {
			 	System.out.println(productName.getText());
			   Count++;
		 }
		 
		 System.out.println("Total Product on Page : " + Count);
 
		
	}

	@Test
	public void TestRun()
	{
		driver.get("https://www.woodenstreet.com/out-of-stock?type=product_breadcrumbs");
	}


}
