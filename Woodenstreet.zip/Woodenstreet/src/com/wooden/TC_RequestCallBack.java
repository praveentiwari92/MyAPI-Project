package com.wooden;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;

public class TC_RequestCallBack {
	WebDriver driver;
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
		

		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.woodenstreet.com");
		 Thread.sleep(10000);
		 driver.findElement(By.className("close")).click();
		 Thread.sleep(800);
		 driver.findElement(By.xpath("/html/body/a[2]")).click();
		 
		 Thread.sleep(1000);
		 driver.findElement(By.id("request_name")).sendKeys("Tester");
		 Thread.sleep(1000);
		 driver.findElement(By.id("request_lname")).sendKeys("Tester");
		 Thread.sleep(1000);
		 driver.findElement(By.id("request_email")).sendKeys("Tester@gmail.com");
		 Thread.sleep(1000);
		 driver.findElement(By.id("request_phone")).sendKeys("1234567890");
		 Thread.sleep(1000);
		 driver.findElement(By.id("request_pincode")).sendKeys("313001");
		 Thread.sleep(2000);
		 driver.findElement(By.id("request_message")).sendKeys("testing");
		 Thread.sleep(1000);
		 driver.findElement(By.xpath("//*[@id=\"feedbackFrom\"]/button")).click();
		 
		 
		 
	}
	
	@Test
	public void TestRun()
	{
		driver.get("https://www.woodenstreet.com");
	}


}
