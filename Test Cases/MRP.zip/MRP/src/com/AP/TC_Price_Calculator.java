package com.AP;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TC_Price_Calculator {
WebDriver driver;
double d = 84.79;
	
	@BeforeClass
	public void TestSetup() throws InterruptedException
	{
		
		
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.assignmentprime.com/");
		 Thread.sleep(3000);
		 // Close Country Pop-up
		 driver.findElement(By.xpath("//i[@class='australia']")).click();
		 Thread.sleep(3000);
		 // close register pop-up
		 driver.findElement(By.xpath("//a[@class='close close_popup']")).click();
		 Thread.sleep(2000);
		 // Select Services
		 driver.findElement(By.xpath("//select[@id='ass_group_list']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//option[contains(text(),'Case Study | Report Writing')]")).click();
		 Thread.sleep(2000);
		 // Select Subjects
		 driver.findElement(By.xpath("//select[@id='assignment_subject']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//option[contains(text(),'Estate Management')]")).click();
		 Thread.sleep(2000);
		// Select Pages
		 driver.findElement(By.xpath("//select[@id='pages_count']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[@id='pages_count_parent']//option[4]")).click();
		 Thread.sleep(2000);
				 
				 
		 // Select Urgency
		 driver.findElement(By.xpath("//select[@id='urgency']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//option[contains(text(),'1 Day')]")).click();
		 Thread.sleep(2000);
		 // Checking Amount Assertion
		 if(d==84.79)
		 {
			 System.out.println("Calculate Amount is :"+d);
		 }
		 
		 else {
			 
			 System.out.println("Amount is wrong");
		 }
		 
		 // Click Order Now Button
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//div[@class='banner_form home clearfix']//input[4]")).click();
		 	
	}	
	
		@Test
		public void Price_Calculator() {
		
		driver.get("https://www.assignmentprime.com/order-now.php");
		driver.quit();
	}
	
	
}
