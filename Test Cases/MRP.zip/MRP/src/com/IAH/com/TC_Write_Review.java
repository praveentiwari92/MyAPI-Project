package com.IAH.com;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_Write_Review {
	
	
	WebDriver driver;
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
	
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.instantassignmenthelp.com/reviews.php");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//ul[@class='clearfix text-center']//a[contains(text(),'UK')]")).click();
		 Thread.sleep(15000);
	//	 driver.findElement(By.xpath("//a[@class='close agree']")).click();
				
	//	 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"open_28271249\"]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.id("title_r")).sendKeys("Tester");
		 Thread.sleep(2000);
		 
		 driver.findElement(By.id("name_r")).sendKeys("Tester");
		 Thread.sleep(2000);
		 driver.findElement(By.id("email_r")).sendKeys("Testcognus@gmail.com");
		 Thread.sleep(2000);
		 driver.findElement(By.id("user_r")).sendKeys("123456");
		 Thread.sleep(2000);
		 driver.findElement(By.id("contain_r")).sendKeys("tester");
		 Thread.sleep(2000);
		 String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:"); 
		 Thread.sleep(2000);
		 driver.findElement(By.id("captcha_code_review")).sendKeys(captchaVal);
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"add_review\"]/button")).click();
		 
		 Thread.sleep(2000);
		// driver.switchTo().alert().dismiss();
		 
		 
	
	
	}
@Test	
public void Review()
{
	driver.get("https://www.instantassignmenthelp.com/reviews.php");
	System.out.println("Test Run Successfully");
	driver.quit();
}
}
