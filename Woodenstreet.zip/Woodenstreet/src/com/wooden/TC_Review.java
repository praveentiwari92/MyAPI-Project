package com.wooden;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;

public class TC_Review {
	
	WebDriver driver;
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
		
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.woodenstreet.com/zadran-study-table-honey-finish");
		 Thread.sleep(10000);
		 driver.navigate().refresh();
		 //driver.findElement(By.className("close")).click();
		 Thread.sleep(800);
		 JavascriptExecutor jse = (JavascriptExecutor)driver;
		 for (int second = 0;; second++) {
	         if(second >=20){
	             break;
	         }
	             jse.executeScript("window.scrollBy(0,200)", ""); //y value �800� can be altered
	             Thread.sleep(1000);
	             
		 	}
	 
		 		JavascriptExecutor js = (JavascriptExecutor) driver;
		 		js.executeScript("window.scrollBy(0,-1700)");
		 		
		 		Thread.sleep(1000);
		 		driver.findElement(By.xpath("//*[@id=\"reviewViewerDiv\"]/div[1]/a")).click();
		 		Thread.sleep(1000);
		 		driver.findElement(By.xpath("//*[@id=\"reviewform_submit\"]/div[1]/span/label[3]")).click();
		 		Thread.sleep(1000);
		 		driver.findElement(By.xpath("//*[@id=\"reviewform_submit\"]/div[2]/input")).sendKeys("tester");
		 		Thread.sleep(1000);
		 		driver.findElement(By.id("review_message")).sendKeys("Tester Tester Tester Tester Tester Tester Tester Tester");
		 		Thread.sleep(1000);
		 		driver.findElement(By.id("product_faq_submit")).click();
		 		Thread.sleep(1000);
		 		String myText = driver.findElement(By.xpath("//*[@id=\"review-popup\"]/div/div/div/p")).getText();
		        System.out.println("Success:  " + myText);
		 		
		 		
	}
	
	
	@Test
	public void TestRun()
	{
		driver.get("https://www.woodenstreet.com/zadran-study-table-honey-finish");
		
	}
	
	

}
