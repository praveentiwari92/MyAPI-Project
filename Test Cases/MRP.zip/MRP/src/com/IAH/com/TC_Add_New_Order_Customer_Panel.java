package com.IAH.com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_Add_New_Order_Customer_Panel {
	WebDriver driver;
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
	
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.instantassignmenthelp.com/customer_panel/");
		 Thread.sleep(2000);
		 
		 driver.findElement(By.id("UserUsername")).sendKeys("testcognus@gmail.com");
		 Thread.sleep(2000);
		 driver.findElement(By.id("UserPassword")).sendKeys("123456");
		 Thread.sleep(2000);
		 driver.findElement(By.className("btn_submit")).click();
		 Thread.sleep(2000);
		
		
		 driver.findElement(By.className("hglt_btn")).click();
		 
		 Thread.sleep(5000);
		 driver.findElement(By.xpath("//*[@id=\"topic\"]")).sendKeys("MBA");
		 Thread.sleep(5000);
		 driver.findElement(By.id("assignment_group_sle")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"assignment_group_sle\"]/option[3]")).click();
		 Thread.sleep(4000);
		 
		 driver.findElement(By.id("assignment_subject")).click();
		 Thread.sleep(4000);
		 driver.findElement(By.xpath("//*[@id=\"assignment_subject\"]/optgroup[1]/option[1]")).click();
		 Thread.sleep(4000);
		 
		 driver.findElement(By.id("pages_count")).click();
		 Thread.sleep(4000);
		 driver.findElement(By.xpath("//*[@id=\"pages_count\"]/option[5]")).click();
		 Thread.sleep(4000);
		 
		 driver.findElement(By.id("urgency")).click();
		 Thread.sleep(4000);
		 driver.findElement(By.xpath("//*[@id=\"urgency\"]/option[6]")).click();
		 Thread.sleep(4000);

		 driver.findElement(By.id("currencies")).click();
		 Thread.sleep(4000);
		 driver.findElement(By.xpath("//*[@id=\"currencies\"]/option[1]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.id("message")).sendKeys("Test");
		 Thread.sleep(2000);
		 WebElement uploadElement = driver.findElement(By.id("file1"));
		 Thread.sleep(1000);
		 uploadElement.sendKeys("C:\\Users\\user\\Pictures\\bill.png"); 
		 
		 driver.findElement(By.id("submitcheckorder")).click();
		 
		// driver.navigate().to("https://www.instantassignmenthelp.com/customer_panel/Users");
		
		 Thread.sleep(2000);
		// driver.findElement(By.xpath("//*[@id=\"left\"]/div/a")).click();
		 
	}
	

	@Test
	public void Add_Order()
	{
		driver.get("https://www.instantassignmenthelp.com/customer_panel/Users");
		System.out.println("Test Run Successfully");
		driver.quit();
		
	}

}
