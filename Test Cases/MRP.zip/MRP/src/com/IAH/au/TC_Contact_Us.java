package com.IAH.au;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_Contact_Us {
	 WebDriver driver;

	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
	
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.instantassignmenthelp.com.au/contact-us.php");
		 Thread.sleep(5000);
		 driver.findElement(By.xpath("//*[@id=\"dialogs\"]/div/a")).click();
		 Thread.sleep(5000);
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,200)");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"contact_us_form\"]/div[1]/input")).sendKeys("Tester");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"contact_us_form\"]/div[2]/input")).sendKeys("Testcognus@gmail.com");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"contact_us_form\"]/div[4]/input[2]")).sendKeys("1234567890");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"contact_us_form\"]/div[5]/textarea")).sendKeys("Tester");
		 Thread.sleep(2000);
		 String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"contact_us_form\"]/div[6]/input")).sendKeys(captchaVal);
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//*[@id=\"contact_us_form\"]/input[2]")).click();
		 
			System.out.println("Contact us Form Submited Successfully");
		 
		 
}
	@Test
	public void Contact_Us()
	{
		
		driver.get("https://www.instantassignmenthelp.com.au/contact-us.php");
		System.out.println("Test Run Successfully");
		driver.quit();
		
		
	}
	
	
	
}