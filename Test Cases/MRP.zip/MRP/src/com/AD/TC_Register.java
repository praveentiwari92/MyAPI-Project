package com.AD;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TC_Register {
	
	WebDriver driver;
	
	@BeforeClass
	public void TestSetup() throws InterruptedException
	{
		
		
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.assignmentdesk.co.uk/");
		 Thread.sleep(2000);
		 // Close country popup
		 driver.findElement(By.xpath("//a[contains(text(),'UK')]")).click();
		 Thread.sleep(5000);
		 // Close seasonal offers popup
		 driver.findElement(By.xpath("//a[@class='close agree']")).click();
		 Thread.sleep(2000);
		 // Click on Login link
		 driver.findElement(By.xpath("//a[@class='login']")).click();
		 Thread.sleep(2000);
		 // Click on Signup
		 driver.findElement(By.xpath("//a[contains(text(),'Sign Up')]")).click();
		 
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//input[@placeholder='Full Name']")).sendKeys("Tester");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//input[@placeholder='Email Address']")).sendKeys("Tester118@gmail.com");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//select[@id='footer_country']")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//option[contains(text(),'Australia')]")).click();
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//input[@id='signup_phone']")).sendKeys("1234567890");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//button[@id='form_button']")).click();
		
		
	}
	
		@Test
		public void Register()
		{
			driver.get("https://www.assignmentdesk.co.uk/customer_panel/dashboard");
			System.out.println("Test Run Successfully");
			driver.quit();
		}
}
