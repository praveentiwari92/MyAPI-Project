package com.AD;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TC_Price_Calculator {
	
WebDriver driver;

	@BeforeClass
	public void TestSetup() throws InterruptedException
	{
		
		
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.assignmentdesk.co.uk/");
		 Thread.sleep(2000);
		 // Close country popup
		 driver.findElement(By.xpath("//a[contains(text(),'UK')]")).click();
		 Thread.sleep(5000);
		 // Close seasonal offers popup
		 driver.findElement(By.xpath("//a[@class='close agree']")).click();
		 Thread.sleep(2000);
		 // Select Services
		 	     driver.findElement(By.xpath("//select[@id='ass_group_list']")).click();
		 		 Thread.sleep(2000);
		 	     driver.findElement(By.xpath("//option[contains(text(),'Case Study | Report Writing')]")).click();
		 Thread.sleep(2000);
		 // Select Subject
		 		 driver.findElement(By.xpath("//select[@id='assignment_subject']")).click();
		 		 Thread.sleep(2000);
		 		 driver.findElement(By.xpath("//option[contains(text(),'Hospitality')]")).click();
		 Thread.sleep(2000);
		// Select Pages
				 driver.findElement(By.xpath("//select[@id='pages_count']")).click();
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//div[@id='pages_count_parent']//option[2]")).click();
				 Thread.sleep(2000);
		// Select Days urgency
				 
				 driver.findElement(By.xpath("//select[@id='urgency']")).click();
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//option[contains(text(),'2 Days')]")).click();
				 Thread.sleep(2000);
				 
		// Submit Order
				 driver.findElement(By.xpath("//input[@class='btns btn-1 btn-1e btn']")).click();
 

}
	
	@Test
	public void Price_Calculator()
	{
		
		System.out.println("Price Calculator");
		
		
		driver.get("https://www.assignmentdesk.co.uk/order-now.php");
		System.out.println("Test Run Successfully");
		 driver.quit();
	}
	
}
