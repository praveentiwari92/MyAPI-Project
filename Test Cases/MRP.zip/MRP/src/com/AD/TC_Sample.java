package com.AD;

import javax.swing.JOptionPane;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TC_Sample {
	
	

WebDriver driver;
	
	@BeforeClass
	public void TestSetup() throws InterruptedException
	{
		
		
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.assignmentdesk.co.uk/samples");
		 Thread.sleep(2000);
		 // Close country popup
		 driver.findElement(By.xpath("//a[contains(text(),'UK')]")).click();
		 Thread.sleep(5000);
		 // Close seasonal offers popup
		 driver.findElement(By.xpath("//a[@class='close agree']")).click();
		 Thread.sleep(2000);
		 JavascriptExecutor js = (JavascriptExecutor) driver;
		 js.executeScript("window.scrollBy(0,200)");
		 // Select Service
		 		 Thread.sleep(2000);
		     	 driver.findElement(By.xpath("//select[@id='ass_group_list']")).click();
		   		 Thread.sleep(2000);
		 		 driver.findElement(By.xpath("//option[contains(text(),'Dissertation & PHD Thesis')]")).click();
		 
		// Select Subject
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//select[@id='assignment_subject']")).click();
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//option[contains(text(),'Commerce')]")).click();
				 
				 
		// Select Words
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//select[@id='pages_count']")).click();
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//li[@id='pages_count_parent']//option[3]")).click();
				 
		// Select Days
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//select[@id='urgency']")).click();
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//option[contains(text(),'3 Days')]")).click();
				 Thread.sleep(2000);
				 // Answer Filter
				 driver.findElement(By.xpath("//li[@class='alphabet']//a[contains(text(),'D')]")).click();
				 Thread.sleep(2000);
			
				 driver.findElement(By.xpath("//a[contains(text(),'All')]")).click();
				 Thread.sleep(2000);
				 // Answer Type
				 driver.findElement(By.xpath("//a[contains(text(),'General Studies')]")).click();
				 Thread.sleep(2000);
				 js.executeScript("window.scrollBy(0,200)");
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//li[1]//div[1]//div[2]//a[1]")).click();
				 Thread.sleep(2000);
				 js.executeScript("window.scrollBy(0,2000)");
				 Thread.sleep(2000);
				 // Get full Answer Report button click
				 driver.findElement(By.xpath("//span[@class='btn']")).click();
				 Thread.sleep(2000);
				 
				 // Fill Form for Sample
				 driver.findElement(By.xpath("//input[@id='email_download']")).sendKeys("Testcognus@gmail.com");
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//input[@id='phone_download']")).sendKeys("1234567890");
				 Thread.sleep(2000);
				 String captchaVal = JOptionPane.showInputDialog("Please enter the captcha value:");
				 Thread.sleep(2000);
				 driver.findElement(By.id("captcha_download")).sendKeys(captchaVal);
				 Thread.sleep(2000);
				 driver.findElement(By.xpath("//li[@class='submit']//button[@class='submit_btn'][contains(text(),'Submit')]")).click();
				 
				
		 
	}
	
	@Test
	public void Sample()
	{
		
		driver.get("https://www.assignmentdesk.co.uk/customer_panel/login");
		System.out.println("Test Run Successfully");
		driver.quit();
	}

}
