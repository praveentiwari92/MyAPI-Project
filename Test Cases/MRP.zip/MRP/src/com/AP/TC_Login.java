package com.AP;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class TC_Login {
	
	WebDriver driver;
	@BeforeClass
	public void TestSetup() throws InterruptedException
	{
		
		
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.assignmentprime.com/");
		 Thread.sleep(3000);
		 // Close Country Pop-up
		 driver.findElement(By.xpath("//i[@class='australia']")).click();
		 Thread.sleep(3000);
		 // close register pop-up
		 driver.findElement(By.xpath("//a[@class='close close_popup']")).click();
		 Thread.sleep(2000);
		 // Click on login
		 driver.findElement(By.className("login")).click();
		 Thread.sleep(2000);
		 // Login Credential insert
		 driver.findElement(By.xpath("//input[@id='UserUsername']")).sendKeys("testcognus@gmail.com");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//input[@id='UserPassword']")).sendKeys("user123");
		 Thread.sleep(2000);
		 driver.findElement(By.xpath("//input[@name='submit']")).click();
		 
		 

}
	@Test
	public void Login()
	{
		
		driver.get("https://www.assignmentprime.com/customer_panel/dashboard");
		System.out.println("Login Successfully");
		driver.quit();
		
	}
}

