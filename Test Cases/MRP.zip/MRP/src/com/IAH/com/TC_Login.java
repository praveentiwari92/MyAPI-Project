package com.IAH.com;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class TC_Login {
	
WebDriver driver;
	
	@BeforeTest
	public void TestSetup() throws InterruptedException
	{
	
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe"); 
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 //Open URL
		 driver.get("https://www.instantassignmenthelp.com/customer_panel/");
		 Thread.sleep(2000);
		 
		 driver.findElement(By.id("UserUsername")).sendKeys("testcognus@gmail.com");
		 Thread.sleep(2000);
		 driver.findElement(By.id("UserPassword")).sendKeys("123456");
		 Thread.sleep(2000);
		 driver.findElement(By.className("btn_submit")).click();
		 
		
		 
	}
	

	@Test
	public void Login()
	{
		driver.get("https://www.instantassignmenthelp.com/customer_panel/dashboard");
		System.out.println("Test Run Succesfully");
		driver.quit();
		
	}
	
}
